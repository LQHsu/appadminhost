import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { HabitacionesModule } from './habitaciones/habitaciones.module';
import { RegistrosModule } from './registros/registros.module';
import { HistorialModule } from './historial/historial.module';
import { Habitacion } from './habitaciones/entities/habitacion.entity';
import { Registro } from './registros/entities/registro.entity';
import { Historial } from './historial/entities/historial.entity';

@Module({
  imports: [
    // SQLite: un solo archivo (hostal.sqlite) en la raíz del proyecto.
    // synchronize:true está bien mientras practicas/desarrollas (crea/
    // actualiza tablas solo a partir de las entidades) pero en un
    // proyecto real usarías migraciones en vez de esto.
    TypeOrmModule.forRoot({
      type: 'better-sqlite3',
      database: 'hostal.sqlite',
      entities: [Habitacion, Registro, Historial],
      synchronize: true,
    }),
    HabitacionesModule,
    RegistrosModule,
    HistorialModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
