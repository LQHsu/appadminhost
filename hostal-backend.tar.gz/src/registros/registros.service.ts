import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { Registro, Renovar } from './entities/registro.entity';
import { Habitacion } from '../habitaciones/entities/habitacion.entity';
import { CreateRegistroDto } from './dto/create-registro.dto';
import { HabitacionesService } from '../habitaciones/habitaciones.service';
import { HistorialService } from '../historial/historial.service';

export type Status = 'VIGENTE' | 'PENDIENTE' | 'RENOVADO' | 'NO';

@Injectable()
export class RegistrosService {
  constructor(
    @InjectRepository(Registro)
    private registrosRepo: Repository<Registro>,
    @InjectRepository(Habitacion)
    private habitacionesRepo: Repository<Habitacion>,
    private habitacionesService: HabitacionesService,
    private historialService: HistorialService,
    private dataSource: DataSource,
  ) {}

  // Traduce literalmente la fórmula de STATUS del Excel:
  // VIGENTE mientras no llega checkout, PENDIENTE si ya pasó y no hay
  // decisión de renovar, RENOVADO si renovar=SI, NO si renovar=NO.
  calcularStatus(registro: Registro): Status {
    const ahora = new Date();
    if (registro.renovar === Renovar.SI) return 'RENOVADO';
    if (registro.renovar === Renovar.NO) return 'NO';
    return ahora < registro.checkOutEstimado ? 'VIGENTE' : 'PENDIENTE';
  }

  private conStatus(registro: Registro) {
    return { ...registro, status: this.calcularStatus(registro) };
  }

  async create(dto: CreateRegistroDto) {
    // 1) valida que existan camas disponibles en esa habitación
    const habitacion = await this.habitacionesService.verificarDisponibilidad(
      dto.habitacionId,
      dto.camasSolicitadas,
    );

    const checkIn = new Date(); // se congela aquí, como en el Excel
    const checkOutEstimado = new Date(checkIn);
    checkOutEstimado.setDate(checkOutEstimado.getDate() + dto.noches);

    const otroCobro = dto.otroCobro ?? 0;
    const totalACobrar =
      dto.camasSolicitadas * dto.costoPorCama * dto.noches + otroCobro;

    const registro = this.registrosRepo.create({
      nombreCliente: dto.nombreCliente,
      camasSolicitadas: dto.camasSolicitadas,
      costoPorCama: dto.costoPorCama,
      noches: dto.noches,
      otroCobro,
      totalACobrar,
      checkOutEstimado,
      habitacion,
      documentoIdentidad: dto.documentoIdentidad,
      metodoPago: dto.metodoPago,
      renovar: dto.renovar ?? Renovar.PENDIENTE,
      atendio: dto.atendio,
    });

    const guardado = await this.registrosRepo.save(registro);
    return this.conStatus(guardado);
  }

  async findAll() {
    const registros = await this.registrosRepo.find({
      where: { cerrado: false },
      relations: { habitacion: true },
      order: { checkIn: 'DESC' },
    });
    return registros.map((r) => this.conStatus(r));
  }

  async findOne(id: number) {
    const registro = await this.registrosRepo.findOne({
      where: { id },
      relations: { habitacion: true },
    });
    if (!registro) throw new NotFoundException(`Registro ${id} no encontrado`);
    return this.conStatus(registro);
  }

  // Actualiza SOLO las "celdas amarillas" editables (ej. marcar renovar).
  async actualizarRenovar(id: number, renovar: Renovar) {
    const registro = await this.registrosRepo.findOne({ where: { id } });
    if (!registro) throw new NotFoundException(`Registro ${id} no encontrado`);
    registro.renovar = renovar;
    // Si renueva, se recorre el checkout estimado otras "noches" más.
    if (renovar === Renovar.SI) {
      const nuevoCheckout = new Date(registro.checkOutEstimado);
      nuevoCheckout.setDate(nuevoCheckout.getDate() + registro.noches);
      registro.checkOutEstimado = nuevoCheckout;
      registro.totalACobrar =
        Number(registro.totalACobrar) +
        registro.camasSolicitadas * Number(registro.costoPorCama) * registro.noches;
      registro.renovar = Renovar.PENDIENTE; // vuelve a quedar VIGENTE con el nuevo periodo
    }
    const guardado = await this.registrosRepo.save(registro);
    return this.conStatus(guardado);
  }

  // Equivalente al botón "CONFIRMAR REGISTRO" (macro VBA) que pediste:
  // copia el registro a Historial y libera las camas, todo en una sola
  // transacción (o pasa completo, o no pasa nada) — esto es justo lo
  // que Excel no puede garantizar sin macros, y con base de datos es gratis.
  async checkout(id: number) {
    return this.dataSource.transaction(async (manager) => {
      const registro = await manager.findOne(Registro, {
        where: { id },
        relations: { habitacion: true },
      });
      if (!registro) throw new NotFoundException(`Registro ${id} no encontrado`);

      const checkOutReal = new Date();

      const historial = manager.create('Historial', {
        registroOriginalId: registro.id,
        nombreCliente: registro.nombreCliente,
        checkIn: registro.checkIn,
        checkOut: checkOutReal,
        camas: registro.camasSolicitadas,
        costoPorCama: registro.costoPorCama,
        noches: registro.noches,
        otroCobro: registro.otroCobro,
        totalCobrado: registro.totalACobrar,
        piso: registro.habitacion.piso,
        habitacionNumero: registro.habitacion.numero,
        documentoIdentidad: registro.documentoIdentidad,
        metodoPago: registro.metodoPago,
        renovarFinal: registro.renovar,
        atendio: registro.atendio,
      });
      await manager.save(historial);

      registro.cerrado = true;
      registro.checkOutReal = checkOutReal;
      await manager.save(registro);

      return { message: 'Registro movido a historial', registroId: id };
    });
  }
}
