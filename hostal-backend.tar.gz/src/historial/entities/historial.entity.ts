import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { MetodoPago, Renovar } from '../../registros/entities/registro.entity';

// Equivalente a la hoja "HISTORIAL DE INGRESOS": una copia congelada
// (valores, no referencias) del registro en el momento en que el
// huésped salió o no renovó. Es justo lo que hacías a mano con
// "Pegado especial > Valores".
@Entity()
export class Historial {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  registroOriginalId: number;

  @Column()
  nombreCliente: string;

  @Column()
  checkIn: Date;

  @Column()
  checkOut: Date;

  @Column()
  camas: number;

  @Column('decimal')
  costoPorCama: number;

  @Column()
  noches: number;

  @Column('decimal')
  otroCobro: number;

  @Column('decimal')
  totalCobrado: number;

  @Column()
  piso: number;

  @Column()
  habitacionNumero: string;

  @Column()
  documentoIdentidad: string;

  @Column({ type: 'simple-enum', enum: MetodoPago })
  metodoPago: MetodoPago;

  @Column({ type: 'simple-enum', enum: Renovar })
  renovarFinal: Renovar;

  @Column()
  atendio: string;
}
