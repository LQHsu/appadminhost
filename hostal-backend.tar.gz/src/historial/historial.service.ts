import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, Repository } from 'typeorm';
import { Historial } from './entities/historial.entity';

@Injectable()
export class HistorialService {
  constructor(
    @InjectRepository(Historial)
    private historialRepo: Repository<Historial>,
  ) {}

  create(data: Partial<Historial>) {
    const historial = this.historialRepo.create(data);
    return this.historialRepo.save(historial);
  }

  findAll() {
    return this.historialRepo.find({ order: { checkOut: 'DESC' } });
  }

  // Equivalente a la tabla de reporte mensual: ingresos totales,
  // efectivo, tarjeta y # de huéspedes, agrupado por el mes que pidas.
  async reporteMensual(anio: number, mes: number) {
    // mes: 1-12
    const inicio = new Date(anio, mes - 1, 1);
    const fin = new Date(anio, mes, 1); // primer día del mes siguiente

    const registros = await this.historialRepo.find({
      where: { checkOut: Between(inicio, fin) },
    });

    const efectivo = registros
      .filter((r) => r.metodoPago === 'EFECTIVO')
      .reduce((sum, r) => sum + Number(r.totalCobrado), 0);
    const tarjeta = registros
      .filter((r) => r.metodoPago === 'TARJETA')
      .reduce((sum, r) => sum + Number(r.totalCobrado), 0);

    return {
      anio,
      mes,
      totalIngresos: efectivo + tarjeta,
      efectivo,
      tarjeta,
      numeroHuespedes: registros.length,
    };
  }
}
