import { Controller, Get, Query, ParseIntPipe } from '@nestjs/common';
import { HistorialService } from './historial.service';

@Controller('historial')
export class HistorialController {
  constructor(private readonly historialService: HistorialService) {}

  @Get()
  findAll() {
    return this.historialService.findAll();
  }

  // Ej: GET /historial/reporte-mensual?anio=2026&mes=8
  @Get('reporte-mensual')
  reporteMensual(
    @Query('anio', ParseIntPipe) anio: number,
    @Query('mes', ParseIntPipe) mes: number,
  ) {
    return this.historialService.reporteMensual(anio, mes);
  }
}
